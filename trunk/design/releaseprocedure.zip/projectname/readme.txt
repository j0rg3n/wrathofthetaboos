Nordic Game Jam 2008 Release form - <30th January 2008>

0) Name of the group.
<SuperDuperGroup>

1) Name of the project:
<Megaproject - The project of projects!>

2) A version number:
<Rev. 201>

3) A written abstract on the project. Max 100 words:
<Greatest game ever built, exploring new aspects of gaming.>

4) Name, E-mail and Group Role of every group member.
<John Doe, john@doe.net, Programmer>
<John Doe, john@doe.net, Sound artist>
<John Doe, john@doe.net, Hangaround>
<...>

5) The platform requirements.
<An Windows XP PC and a Joystick.>
<DirectX 9.0c and the latest BonziBUDDY installed.>
<Minimum resolution of 800x600>

6) The folders must contain:
/src/: The full sourcecode, with all assets of the project.
/release/: The distributable files.
/press/: One hi-res image called press.jpg, to be used for PR, Hires 1024x768 or better.
Other media can also be put here. E.g: Videos etc.

7) A install description on how to try the release out.
<Go to the release folder and unzip rel.zip to c:\>
<Connect the joystick and run c:\coolgame\main.exe>

8) A brief play description if nescesary.
<You are the brown pea. You have to use the arrowkeys to control gravity to make it roll towards its goal.>

9) Copyright notes.
It is rewuired that the project is submitted under the MIT license. http://en.wikipedia.org/wiki/MIT_license

If this poses a problem please, contact the Nordic Game Jam Group.

Copyright (c) <year> <copyright holders>

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.



10) A reference to a project homepage or repository where possible further development can continue from.(Optional)

11) A link to the zipfile should be sent in an email to: submissions@nordicgamejam.com, alongside possible login information, projectname, teamname and membernames  (please note .com instead of .org in the email address).

Everything must be available for download from the public internet for at least one week, no later than Sunday the 2nd of February 2008 at 15:00!

Teams will be notified through an email reply when NGJ has recieved the data. 

You can use any service available on the internet, but Nordic Game Jam recommend www.assembla.com. 
They provide a full project management system, repository and file upload space (Public or private). 
500MB space available for free.

Alternatively you could use: http://code.google.com/hosting/

If you find a better deal please notify the NGJ staff.
