java -Djava.library.path=jme/lib/ \
	-Xmx512M \
	-cp ".:release/JealousGods.jar:jme/lib/lwjgl.jar:jme/lib/jinput.jar:jme/lib/junit-4.1.jar:jme/lib/jogg-0.0.7.jar:jme/lib/jorbis-0.0.15.jar" \
	net.hokuspokus.wott.client.WrathOfTaboo
